<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/icons.php';
require_auth();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    csrf_check_post();
    $name = trim($_POST['name_product'] ?? '');
    if ($name === '') {
        flash('error', 'نام محصول الزامی است.');
        header('Location: product.php');
        exit;
    }
    if (db_count($pdo, "SELECT COUNT(*) FROM product WHERE name_product = ?", [$name])) {
        flash('error', 'محصولی با این نام قبلاً ثبت شده است.');
        header('Location: product.php');
        exit;
    }
    $code = bin2hex(random_bytes(2));
    try {
        db_query(
            $pdo,
            "INSERT INTO product (name_product,code_product,price_product,Volume_constraint,Service_time,Location,agent,data_limit_reset,note,category,hide_panel,one_buy_status,limitip) VALUES (?,?,?,?,?,?,?,'no_reset',?,?,'{}','0',?)",
            [
                $name,
                $code,
                (int) ($_POST['price_product'] ?? 0),
                (int) ($_POST['volume_product'] ?? 0),
                (int) ($_POST['time_product'] ?? 0),
                $_POST['namepanel'] ?? '',
                $_POST['agent_product'] ?? 'f',
                $_POST['note_product'] ?? '',
                $_POST['category_product'] ?? '',
                (int) ($_POST['limitip'] ?? 0)
            ]
        );
        flash('success', 'محصول «' . htmlspecialchars($name) . '» با موفقیت اضافه شد.');
    } catch (Exception $e) {
        flash('error', 'خطای پایگاه داده: ' . $e->getMessage());
    }
    header('Location: product.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
    csrf_check_post();
    $pid = (int) ($_POST['edit_id'] ?? 0);
    $name = trim($_POST['name_product'] ?? '');
    if ($pid && $name !== '') {
        try {
            db_query(
                $pdo,
                "UPDATE product SET name_product=?,price_product=?,Volume_constraint=?,Service_time=?,Location=?,agent=?,note=?,category=?,limitip=? WHERE id=?",
                [
                    $name,
                    (int) ($_POST['price_product'] ?? 0),
                    (int) ($_POST['volume_product'] ?? 0),
                    (int) ($_POST['time_product'] ?? 0),
                    $_POST['namepanel'] ?? '',
                    $_POST['agent_product'] ?? 'f',
                    $_POST['note_product'] ?? '',
                    $_POST['category_product'] ?? '',
                    (int) ($_POST['limitip'] ?? 0),
                    $pid
                ]
            );
            flash('success', 'محصول با موفقیت ویرایش شد.');
        } catch (Exception $e) {
            flash('error', 'خطا در ویرایش: ' . $e->getMessage());
        }
    }
    header('Location: product.php');
    exit;
}

if (isset($_GET['delete'])) {
    csrf_check_get();
    $delId = (int) $_GET['delete'];
    try {
        db_query($pdo, "DELETE FROM product WHERE id = ?", [$delId]);
        flash('success', 'محصول با موفقیت حذف شد.');
    } catch (Exception $e) {
        flash('error', 'خطا در حذف محصول: ' . $e->getMessage());
    }
    header('Location: product.php');
    exit;
}

$panels = [];
$categories = [];
try {
    $panels = db_fetchAll($pdo, "SELECT * FROM marzban_panel");
    $categories = db_fetchAll($pdo, "SELECT * FROM category");
} catch (Exception $e) {
}
$products = db_fetchAll($pdo, "SELECT * FROM product ORDER BY id DESC");

$pageTitle = 'مدیریت محصولات';
$pageLede = 'فهرست، تعریف و ویرایش پلن‌ها و تعرفه‌ها';
$activeNav = 'product';
include __DIR__ . '/inc/layout_head.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px" class="fade-up">
  <div style="font-size:.85rem;color:var(--mute)"><?= count($products) ?> محصول تعریف شده</div>
  <button type="button" class="btn btn-primary" onclick="openModal('addModal')" data-modal-open="addModal"><?= icon('plus', 14) ?> افزودن محصول جدید</button>
</div>

<div class="card fade-up d1">
  <?php if (empty($products)): ?>
    <div class="empty" style="padding:60px 20px">
      <svg class="ill" viewBox="0 0 200 160" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="40" y="30" width="120" height="100" rx="12" fill="var(--sf3)" />
        <rect x="56" y="50" width="88" height="12" rx="6" fill="var(--bds)" />
        <rect x="56" y="72" width="60" height="8" rx="4" fill="var(--bd)" />
        <rect x="56" y="90" width="72" height="8" rx="4" fill="var(--bd)" />
        <rect x="56" y="108" width="44" height="8" rx="4" fill="var(--bd)" />
        <circle cx="155" cy="125" r="22" fill="var(--acs)" stroke="var(--ac)" stroke-width="2" />
        <path d="M147 125h16M155 117v16" stroke="var(--ac)" stroke-width="2.5" stroke-linecap="round" />
      </svg>
      <p>هنوز محصولی ثبت نکرده‌اید</p>
      <button type="button" class="btn btn-primary" style="margin-top:14px" onclick="openModal('addModal')" data-modal-open="addModal"><?= icon('plus', 14) ?> اضافه کردن اولین محصول</button>
    </div>
  <?php else: ?>
    <div class="toolbar">
      <div class="toolbar-title">فهرست محصولات <small>(<?= count($products) ?>)</small></div>
      <div class="search-box" style="min-width:220px">
        <?= icon('search', 14) ?>
        <input type="text" placeholder="جستجوی نام یا کد..." data-filter="prodTbl">
        <button type="button" class="search-clear">✕</button>
      </div>
    </div>
    <div class="tbl-wrap">
      <table id="prodTbl" class="tbl-xl">
        <thead>
          <tr>
            <th style="width:40px">#</th>
            <th>نام محصول</th>
            <th>قیمت</th>
            <th>حجم</th>
            <th>مدت</th>
            <th>پنل (سرور)</th>
            <th>دسته‌بندی</th>
            <th>محدودیت کاربر</th>
            <th>کد</th>
            <th style="width:100px;text-align:center">عملیات</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; foreach ($products as $p): ?>
            <tr>
              <td class="cf"><?= $i++ ?></td>
              <td class="cs"><?= htmlspecialchars($p['name_product'] ?? '') ?></td>
              <td class="cn cs"><?= number_format((int) ($p['price_product'] ?? 0)) ?> <span class="cf">تومان</span></td>
              <td class="cn"><?= ((int)($p['Volume_constraint'] ?? 0) > 0 ? htmlspecialchars($p['Volume_constraint']) . ' <span class="cf">GB</span>' : '<span class="tag tag-plain">نامحدود</span>') ?></td>
              <td class="cn"><?= ((int)($p['Service_time'] ?? 0) > 0 ? htmlspecialchars($p['Service_time']) . ' <span class="cf">روز</span>' : '<span class="tag tag-plain">نامحدود</span>') ?></td>
              <td class="cf"><?= htmlspecialchars(empty($p['Location']) || $p['Location'] === '/all' ? 'همه سرورها' : trunc($p['Location'], 16)) ?></td>
              <td><?php if (!empty($p['category'])): ?><span class="tag tag-info"><?= htmlspecialchars($p['category']) ?></span><?php else: ?><span class="cf">—</span><?php endif; ?></td>
              <td><span class="tag <?= ((int)($p['limitip'] ?? 0) > 0 ? 'tag-warn' : 'tag-plain') ?>"><?= ((int)($p['limitip'] ?? 0) > 0 ? (int)$p['limitip'] . ' کاربر' : 'نامحدود') ?></span></td>
              <td class="cm" style="font-size:.72rem"><?= htmlspecialchars($p['code_product'] ?? '') ?></td>
              <td style="text-align:center">
                <div style="display:inline-flex;gap:5px">
                  <button type="button" class="btn btn-ghost btn-sm btn-icon" title="ویرایش محصول"
                    data-product="<?= htmlspecialchars(json_encode($p, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') ?>"
                    onclick="openEditModal(this.dataset.product)">
                    <?= icon('edit', 13) ?>
                  </button>
                  <a href="product.php?delete=<?= (int) $p['id'] ?>&_csrf=<?= csrf_token() ?>"
                    class="btn btn-no btn-sm btn-icon" title="حذف محصول"
                    data-confirm="آیا از حذف محصول «<?= htmlspecialchars($p['name_product'] ?? '') ?>» اطمینان دارید؟">
                    <?= icon('trash', 13) ?>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="modal-veil" id="addModal">
  <div class="modal">
    <div class="modal-head">
      <h3>افزودن محصول جدید</h3>
      <button type="button" class="modal-x" onclick="closeModal('addModal')" data-modal-close="addModal"><?= icon('close', 14) ?></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="add">
        <div class="form-grid">
          <div class="field full">
            <label>نام محصول *</label>
            <input type="text" name="name_product" class="input" placeholder="مثلاً: ۵۰ گیگ یک ماهه" required>
          </div>
          <div class="field">
            <label>قیمت (تومان)</label>
            <input type="number" name="price_product" class="input" placeholder="0" min="0" value="0">
          </div>
          <div class="field">
            <label>حجم (گیگابایت - 0 یعنی نامحدود)</label>
            <input type="number" name="volume_product" class="input" placeholder="50" min="0" value="0">
          </div>
          <div class="field">
            <label>مدت اعتبار (روز - 0 یعنی نامحدود)</label>
            <input type="number" name="time_product" class="input" placeholder="30" min="0" value="30">
          </div>
          <div class="field">
            <label>دسته‌بندی</label>
            <select name="category_product" class="select">
              <option value="">— بدون دسته‌بندی —</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= htmlspecialchars($cat['remark'] ?? '') ?>">
                  <?= htmlspecialchars($cat['remark'] ?? '') ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>پنل سرور (لوکیشن)</label>
            <select name="namepanel" class="select">
              <option value="">— همه پنل‌ها (/all) —</option>
              <?php foreach ($panels as $pl): ?>
                <option value="<?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>">
                  <?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>نوع دسترسی (نمایندگی)</label>
            <select name="agent_product" class="select">
              <option value="f">کاربر عادی</option>
              <option value="n">نماینده</option>
              <option value="n2">نماینده پیشرفته</option>
            </select>
          </div>
          <div class="field">
            <label>محدودیت IP (تعداد کاربر همزمان)</label>
            <input type="number" name="limitip" class="input" placeholder="0 (نامحدود)" min="0" value="0">
          </div>
          <div class="field full">
            <label>یادداشت / توضیحات محصول (اختیاری)</label>
            <input type="text" name="note_product" class="input" placeholder="توضیحاتی که در پیش‌فاکتور به کاربر نمایش داده می‌شود...">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="submit" class="btn btn-primary"><?= icon('plus', 13) ?> ذخیره محصول</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('addModal')" data-modal-close="addModal">انصراف</button>
      </div>
    </form>
  </div>
</div>

<div class="modal-veil" id="editModal">
  <div class="modal">
    <div class="modal-head">
      <h3>ویرایش محصول</h3>
      <button type="button" class="modal-x" onclick="closeModal('editModal')" data-modal-close="editModal"><?= icon('close', 14) ?></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="edit_id" id="edit_id">
        <div class="form-grid">
          <div class="field full">
            <label>نام محصول *</label>
            <input type="text" name="name_product" id="edit_name" class="input" required>
          </div>
          <div class="field">
            <label>قیمت (تومان)</label>
            <input type="number" name="price_product" id="edit_price" class="input" min="0">
          </div>
          <div class="field">
            <label>حجم (گیگابایت - 0 یعنی نامحدود)</label>
            <input type="number" name="volume_product" id="edit_volume" class="input" min="0">
          </div>
          <div class="field">
            <label>مدت اعتبار (روز - 0 یعنی نامحدود)</label>
            <input type="number" name="time_product" id="edit_time" class="input" min="0">
          </div>
          <div class="field">
            <label>دسته‌بندی</label>
            <select name="category_product" id="edit_cat" class="select">
              <option value="">— بدون دسته‌بندی —</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= htmlspecialchars($cat['remark'] ?? '') ?>">
                  <?= htmlspecialchars($cat['remark'] ?? '') ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>پنل سرور (لوکیشن)</label>
            <select name="namepanel" id="edit_panel" class="select">
              <option value="">— همه پنل‌ها (/all) —</option>
              <?php foreach ($panels as $pl): ?>
                <option value="<?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>">
                  <?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>نوع دسترسی (نمایندگی)</label>
            <select name="agent_product" id="edit_agent" class="select">
              <option value="f">کاربر عادی</option>
              <option value="n">نماینده</option>
              <option value="n2">نماینده پیشرفته</option>
            </select>
          </div>
          <div class="field">
            <label>محدودیت IP (تعداد کاربر همزمان)</label>
            <input type="number" name="limitip" id="edit_limitip" class="input" min="0" value="0">
          </div>
          <div class="field full">
            <label>یادداشت / توضیحات محصول (اختیاری)</label>
            <input type="text" name="note_product" id="edit_note" class="input">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="submit" class="btn btn-primary"><?= icon('check', 13) ?> ذخیره تغییرات</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('editModal')" data-modal-close="editModal">انصراف</button>
      </div>
    </form>
  </div>
</div>

<script src="js/product.js"></script>

<?php include __DIR__ . '/inc/layout_foot.php'; ?>
