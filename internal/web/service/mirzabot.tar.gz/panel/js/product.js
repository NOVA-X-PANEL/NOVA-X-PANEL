window.openEditModal = function (p) {
    if (typeof p === 'string') {
        try {
            p = JSON.parse(p);
        } catch (e) {
            console.error('Failed to parse product data', e);
            return;
        }
    }
    if (!p) return;
    var elId = document.getElementById('edit_id');
    if (elId) elId.value = p.id || '';
    var elName = document.getElementById('edit_name');
    if (elName) elName.value = p.name_product || '';
    var elPrice = document.getElementById('edit_price');
    if (elPrice) elPrice.value = p.price_product !== undefined ? p.price_product : '0';
    var elVol = document.getElementById('edit_volume');
    if (elVol) elVol.value = p.Volume_constraint !== undefined ? p.Volume_constraint : '0';
    var elTime = document.getElementById('edit_time');
    if (elTime) elTime.value = p.Service_time !== undefined ? p.Service_time : '0';
    var elCat = document.getElementById('edit_cat');
    if (elCat) elCat.value = p.category || '';
    var elAgent = document.getElementById('edit_agent');
    if (elAgent) elAgent.value = p.agent || 'f';
    var elNote = document.getElementById('edit_note');
    if (elNote) elNote.value = p.note || '';
    var limitField = document.getElementById('edit_limitip');
    if (limitField) limitField.value = p.limitip !== undefined ? p.limitip : 0;

    var sel = document.getElementById('edit_panel');
    if (sel) {
        for (var i = 0; i < sel.options.length; i++) {
            sel.options[i].selected = sel.options[i].value === (p.Location || '');
        }
    }

    openModal('editModal');
};
