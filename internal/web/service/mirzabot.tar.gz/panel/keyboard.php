<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/icons.php';
require_once __DIR__ . '/../botapi.php';
require_auth();

// Ensure session is properly initialized
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['admin_user'])) {
    $admin = select("admin", "*", null, null, "select");
    if ($admin) {
        $_SESSION['admin_user'] = $admin['username'] ?? $admin['id_admin'];
    }
}

setcookie('XSRF-TOKEN', csrf_token(), [
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);

$method = $_SERVER['REQUEST_METHOD'];
$keyboardInput = json_decode(file_get_contents("php://input"), true);

if ($method === "POST" && is_array($keyboardInput)) {
    $keyboard = $keyboardInput['keyboard'] ?? $keyboardInput;
    $validKeyboard = count($keyboard) > 0;
    foreach ($keyboard as $row) {
        if (!is_array($row) || count($row) === 0) {
            $validKeyboard = false;
            break;
        }
        foreach ($row as $button) {
            if (!is_array($button) || !isset($button['text']) || !is_string($button['text']) || trim($button['text']) === '') {
                $validKeyboard = false;
                break 2;
            }
        }
    }
    header('Content-Type: application/json; charset=utf-8');
    if (!$validKeyboard) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'ساختار کیبورد نامعتبر است.']);
        exit;
    }
    $keyboardmain = ['keyboard' => $keyboard];
    update("setting", "keyboardmain", json_encode($keyboardmain, JSON_UNESCAPED_UNICODE), null, null);
    echo json_encode(['ok' => true, 'msg' => 'کیبورد و رنگ‌ها با موفقیت ذخیره شدند.']);
    exit;
}

$defaultKeyboardJson = '{"keyboard":[[{"text":"text_sell"},{"text":"text_extend"}],[{"text":"text_usertest"},{"text":"text_wheel_luck"}],[{"text":"text_Purchased_services"},{"text":"accountwallet"}],[{"text":"text_affiliates"},{"text":"text_Tariff_list"}],[{"text":"text_support"},{"text":"text_help"}],[{"text":"text_agentpanel"},{"text":"text_requestagent"}]]}';

$action = filter_input(INPUT_GET, 'action');
if ($action === "reaset") {
    csrf_check_get();
    update("setting", "keyboardmain", $defaultKeyboardJson, null, null);
    header('Location: keyboard.php');
    exit;
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>مدیریت و رنگ‌بندی دکمه‌های ربات | NOVA SHOP</title>

    <script type="module" crossorigin src="js/sort_keyboard.js"></script>
    <link rel="stylesheet" crossorigin href="css/sort_keyboard.css">
    <link rel="stylesheet" href="css/cyberpunk_theme.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');
        
        * {
            box-sizing: border-box;
            font-family: 'Vazirmatn', -apple-system, sans-serif !important;
        }

        body {
            background-color: #06090e !important;
            color: #e2e8f0 !important;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Top Bar */
        .nova-topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: linear-gradient(180deg, rgba(13, 19, 33, 0.95) 0%, rgba(8, 12, 22, 0.9) 100%);
            border-bottom: 1px solid rgba(0, 240, 255, 0.2);
            padding: 12px 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            position: sticky;
            top: 0;
            z-index: 9999;
            backdrop-filter: blur(10px);
        }

        .nova-title-group {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nova-badge {
            background: rgba(0, 240, 255, 0.12);
            color: #00f0ff;
            border: 1px solid rgba(0, 240, 255, 0.4);
            font-size: 11px;
            font-weight: 700;
            padding: 3px 8px;
            border-radius: 4px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .nova-title {
            font-size: 16px;
            font-weight: 700;
            color: #ffffff;
            margin: 0;
        }

        .nova-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nova-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
        }

        .nova-btn-back {
            background: rgba(255, 255, 255, 0.05);
            color: #94a3b8;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .nova-btn-back:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            border-color: rgba(255, 255, 255, 0.2);
        }

        .nova-btn-reset {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.25);
        }
        .nova-btn-reset:hover {
            background: rgba(239, 68, 68, 0.2);
            color: #fca5a5;
            border-color: rgba(239, 68, 68, 0.5);
        }

        /* Tip Callout */
        .nova-hint-box {
            max-width: 900px;
            margin: 18px auto 0 auto;
            background: rgba(0, 240, 255, 0.04);
            border: 1px solid rgba(0, 240, 255, 0.2);
            border-radius: 10px;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            color: #bae6fd;
            font-size: 13.5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        /* React Container Overrides for Cyberpunk Dark Theme */
        #root {
            min-height: calc(100vh - 80px);
            padding: 16px;
        }

        #root .bg-slate-200 {
            background-color: #0b101b !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            border-radius: 14px !important;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4) !important;
        }

        #root .bg-white {
            background-color: #121929 !important;
            color: #f1f5f9 !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
        }

        #root input, #root select, #root textarea {
            background-color: #090d16 !important;
            border: 1px solid rgba(0, 240, 255, 0.25) !important;
            color: #f8fafc !important;
            border-radius: 6px !important;
        }

        #root button {
            border-radius: 6px !important;
        }
    </style>
</head>

<body>
    <header class="nova-topbar">
        <div class="nova-title-group">
            <span class="nova-badge">NOVA SHOP</span>
            <h1 class="nova-title">تنظیم چیدمان و رنگ‌بندی دکمه‌های ربات تلگرام</h1>
        </div>
        <div class="nova-actions">
            <a class="nova-btn nova-btn-reset" href="keyboard.php?action=reaset&_csrf=<?= urlencode(csrf_token()) ?>">
                <span>↺</span> بازنشانی پیش‌فرض
            </a>
            <a class="nova-btn nova-btn-back" href="product.php">
                <span>←</span> مدیریت محصولات
            </a>
            <a class="nova-btn nova-btn-back" href="index.php">
                <span>🏠</span> داشبورد پنل
            </a>
        </div>
    </header>

    <div class="nova-hint-box">
        <span style="font-size: 20px;">🎨</span>
        <div>
            <strong>راهنمای تغییر رنگ:</strong>
            برای تغییر عنوان یا رنگ هر دکمه، کافیست روی دکمه مورد نظر کلیک کنید تا منوی انتخاب رنگ باز شود. رنگ دلخواه را انتخاب نمایید و پس از اتمام دکمه ذخیره را بزنید.
        </div>
    </div>

    <div id="root"></div>
</body>
</html>
