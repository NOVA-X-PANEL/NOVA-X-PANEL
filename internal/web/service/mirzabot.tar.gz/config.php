<?php
// This variable added for high load panels which their response time is long and bot can't communicate with online panel!
// null for default settings
$request_exec_timeout = null;
$dbhost = 'localhost';
$dbname = 'mirzabot';
$usernamedb = 'mirzauser';
$passworddb = 'MirzaDbSecure91107!_';
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
];
$dsn = "mysql:host=$dbhost;dbname=$dbname;charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $usernamedb, $passworddb, $options);
} catch (\PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("error: database connection failed");
}
$APIKEY = '8781465649:AAEEKMK_umrtGoi8zcc6Osm3kroWOD_eSI4';
$adminnumber = '842798945';
$domainhosts = 'dark.ksmrx2.ir';
$usernamebot = 'Jfjfifidrhobxuhdy_bot';

?>
